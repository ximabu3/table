<?php

@include 'config.php';

if(isset($_post['submit'])){
    $id = mysqli_real_escape_string($_post['user id']);
    $email = mysqli_real_escape_string($_post['email']);
    $pass = md5($_POST['password']);

    $select = " SELECT * FROM user_form WHERE email= '$email' && password = '$pass' ";

    $result = mysqli_query($conn, $select);

    if(mysqli_num_rows($result) > 0){
        $error[] = 'user already exist!';
    }
    mysqli_query($conn, $insert);
    header('location:account.php');
};

?>




<?php
                 if(isset($error)){
                    foreach($error as $error){
                        echo '<span class="error-msg">.$error.</span>';
                    };
                 };
                ?>